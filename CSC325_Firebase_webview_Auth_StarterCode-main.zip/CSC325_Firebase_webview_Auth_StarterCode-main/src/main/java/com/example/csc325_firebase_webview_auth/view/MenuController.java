package com.example.csc325_firebase_webview_auth.view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class MenuController {


    @FXML
    private Button logIn, signUp;


    @FXML
    private void setLogInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/loginPage.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) logIn.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 813, 553);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }


    @FXML
    private void setSignUp() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/signup.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) logIn.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 813, 553);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
}
