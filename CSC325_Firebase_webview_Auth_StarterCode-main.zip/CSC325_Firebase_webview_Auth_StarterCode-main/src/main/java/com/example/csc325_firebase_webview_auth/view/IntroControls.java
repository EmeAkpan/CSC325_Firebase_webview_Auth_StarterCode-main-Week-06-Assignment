package com.example.csc325_firebase_webview_auth.view;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.auth.FirebaseAuthException;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IntroControls {

@FXML
private Button back;


    @FXML
    private TextField usernameField;



    @FXML
    private PasswordField passwordField;


    @FXML
    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/menu.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) back.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    @FXML
    private void logInButton() {
        // Get user input for username and password
        String inputUsername = usernameField.getText();
        String inputPassword = passwordField.getText();

        // Asynchronously retrieve documents from the "signupresource" collection
        ApiFuture<QuerySnapshot> future = App.fstore.collection("signupresource").get();

        try {
            List<QueryDocumentSnapshot> documents = future.get().getDocuments();

            // Iterate over documents to check for matching username and password
            for (QueryDocumentSnapshot document : documents) {
                String username = document.getString("username");
                String password = document.getString("password");

                // Check if input username and password match
                if (inputUsername.equals(username) && inputPassword.equals(password)) {
                    // If credentials match, call finishSetUp() method
                    finishSetUp();
                    System.out.println("Log in Successful");
                    return; // Exit the method
                }
            }

            // If no match found, display an alert indicating incorrect credentials
            showAlert(Alert.AlertType.ERROR, "Error", "Username/Password Incorrect", "Please try again");

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void finishSetUp(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/AccessFBView.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) back.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 790, 503);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }




}
