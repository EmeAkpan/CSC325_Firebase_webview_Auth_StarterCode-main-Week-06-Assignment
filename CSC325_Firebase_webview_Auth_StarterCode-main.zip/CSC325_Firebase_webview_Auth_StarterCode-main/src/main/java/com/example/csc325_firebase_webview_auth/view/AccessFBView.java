package com.example.csc325_firebase_webview_auth.view;//package modelview;

import com.example.csc325_firebase_webview_auth.model.Person;


import com.example.csc325_firebase_webview_auth.viewmodel.AccessDataViewModel;
import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class AccessFBView {


    @FXML
    private TextField nameField;
    @FXML
    private TextField majorField;
    @FXML
    private TextField ageField;
    @FXML
    private Button writeButton;
    @FXML
    private Button readButton;
    @FXML
    private TextArea outputField;

    @FXML
    private TableView<Person> tableView;

    // Reference to the columns in the TableView
    @FXML
    private Button back;
    @FXML
    private TableColumn<Person, String> nameColumn;
    @FXML
    private TableColumn<Person, String> majorColumn;
    @FXML
    private TableColumn<Person, Integer> ageColumn;
     private boolean key;
    private ObservableList<Person> listOfUsers = FXCollections.observableArrayList();
    private Person person;
    public ObservableList<Person> getListOfUsers() {
        return listOfUsers;
    }

    @FXML
    void initialize() {

        AccessDataViewModel accessDataViewModel = new AccessDataViewModel();
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        majorColumn.setCellValueFactory(new PropertyValueFactory<>("Major"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("Age"));


    }

    @FXML
    private void addRecord(ActionEvent event) {
        addData();
        clear();
    }

        @FXML
    private void readRecord(ActionEvent event) {
        readFirebase();
    }

            @FXML
    private void regRecord(ActionEvent event) {
        registerUser();
    }

     @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("/files/WebContainer.fxml");
    }

    public void addData() {

        DocumentReference docRef = App.fstore.collection("References").document(UUID.randomUUID().toString());

        Map<String, Object> data = new HashMap<>();
        data.put("Name", nameField.getText());
        data.put("Major", majorField.getText());
        data.put("Age", Integer.parseInt(ageField.getText()));
        //asynchronously write data
        ApiFuture<WriteResult> result = docRef.set(data);

    }

    public boolean readFirebase() {
        key = false;

        // Asynchronously retrieve all documents from Firebase
        ApiFuture<QuerySnapshot> future = App.fstore.collection("References").get();

        try {
            List<QueryDocumentSnapshot> documents = future.get().getDocuments();
            // Initialize list before adding items
            listOfUsers.clear(); // Clear existing items if any
            if (!documents.isEmpty()) {
                System.out.println("Outing....");
                for (QueryDocumentSnapshot document : documents) {
                    // Extract data from document
                    String name = document.getString("Name");
                    String major = document.getString("Major");
                    int age = document.getLong("Age").intValue();

                    // Create a new Person object with extracted data
                    Person person = new Person(name, major, age);

                    // Add the Person object to the list of users
                    listOfUsers.add(person);
                    System.out.println("data collecting");
                }
                // Set items to TableView outside of loop
                tableView.setItems(listOfUsers);
                System.out.println("data insterted into table");
            } else {
                System.out.println("No data");
            }
            key = true;
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return key;
    }

    public void sendVerificationEmail() {
        try {
            UserRecord user = App.fauth.getUser("name");
            //String url = user.getPassword();

        } catch (Exception e) {
        }
    }
    @FXML
    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/menu.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) back.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    public boolean registerUser() {
        UserRecord.CreateRequest request = new UserRecord.CreateRequest()
                .setEmail("user@example.com")
                .setEmailVerified(false)
                .setPassword("secretPassword")
                .setPhoneNumber("+11234567890")
                .setDisplayName("John Doe")
                .setDisabled(false);

        UserRecord userRecord;
        try {
            userRecord = App.fauth.createUser(request);
            System.out.println("Successfully created new user: " + userRecord.getUid());
            return true;

        } catch (FirebaseAuthException ex) {
           // Logger.getLogger(FirestoreContext.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

        @FXML
    private void clear() {

        nameField.clear();
        majorField.clear();
        ageField.clear();
    }


}
