package com.example.csc325_firebase_webview_auth.view;


import com.example.csc325_firebase_webview_auth.model.FirestoreContext;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.auth.FirebaseAuth;
import java.io.IOException;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * JavaFX App
 */
public class App extends Application {

    public static Firestore fstore;
    public static FirebaseAuth fauth;
    public static Scene scene;
    private final FirestoreContext contxtFirebase = new FirestoreContext();

    @Override
    public void start(Stage primaryStage) throws Exception {
        fstore = contxtFirebase.firebase();
        fauth = FirebaseAuth.getInstance();
        FXMLLoader splashLoader = new FXMLLoader(getClass().getResource("/files/splash.fxml"));
        Parent splashRoot = splashLoader.load();
        Scene splashScene = new Scene(splashRoot);

        // Show the splash screen
        primaryStage.setScene(splashScene);
        primaryStage.show();

        // Pause for 3 seconds and then load the next page
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        delay.setOnFinished(event -> {
            try {
                // Load the next page (menu.fxml)
                FXMLLoader menuLoader = new FXMLLoader(getClass().getResource("/files/menu.fxml"));
                Parent menuRoot = menuLoader.load();

                // Get the stage from the splash screen
                Stage stage = (Stage) splashRoot.getScene().getWindow();

                // Set the new scene
                Scene menuScene = new Scene(menuRoot );
                stage.setScene(menuScene);
            } catch (IOException e) {
                e.printStackTrace();
                // Handle exception
            }
        });
        delay.play();
    }

    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml ));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
