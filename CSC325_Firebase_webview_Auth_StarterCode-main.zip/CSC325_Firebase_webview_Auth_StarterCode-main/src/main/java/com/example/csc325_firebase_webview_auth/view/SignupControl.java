package com.example.csc325_firebase_webview_auth.view;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.cloud.FirestoreClient;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

public class SignupControl {
    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;
    @FXML
    private Button back;



    @FXML
    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/menu.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) back.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }



    @FXML
    private void signUpUser() {
        // Check if any field is empty
        if (usernameField.getText().isEmpty() || emailField.getText().isEmpty() || passwordField.getText().isEmpty()) {
            // Display an alert indicating that all fields must be filled
            showAlert(Alert.AlertType.ERROR, "Error", "Missing Information", "Please fill in all fields");
            return;
        }

        // Get a Firestore instance
        Firestore firestore = FirestoreClient.getFirestore();

        // Generate a random document ID
        String userId = UUID.randomUUID().toString();

        // Create a DocumentReference for the new user
        DocumentReference userRef = firestore.collection("signupresource").document(userId);

        // Create a map to store user information
        Map<String, Object> userData = new HashMap<>();
        userData.put("username", usernameField.getText());
        userData.put("email", emailField.getText());
        userData.put("password", passwordField.getText());

        // Asynchronously write user data to Firestore
        try {
            ApiFuture<WriteResult> result = userRef.set(userData);
            result.get(); // Wait for the operation to complete
            showAlert(Alert.AlertType.INFORMATION, "Success", "User Signed Up", "User signed up successfully");
            finishSetUp();
        } catch (InterruptedException | ExecutionException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Sign Up Failed", "Error signing up user: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    public void finishSetUp(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/files/AccessFBView.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) back.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(root, 790, 503);
            stage.setScene(scene);

            // Calculate the center position of the screen
            double centerX = (Screen.getPrimary().getVisualBounds().getWidth() - scene.getWidth()) / 2;
            double centerY = (Screen.getPrimary().getVisualBounds().getHeight() - scene.getHeight()) / 2;

            // Set the stage position to the center
            stage.setX(centerX);
            stage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
}